<?php
  include_once("db.php");
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include_once("db.php");
    $query = "select * from teams where team_name = ?";
    $stmt = $db->prepare($query);
    $stmt->bindParam(1, $_POST['iteamname'], PDO::PARAM_STR);
    $stmt->execute();
    $count = $stmt->rowCount();
    if($count > 0) {
      $_SESSION['errorMessage']="Team exists.";
    } else {
      // insert a new instructor
      $query = "select * from teams where team_name = ?";
      $stmt = $db->prepare($query);
      $stmt->bindParam(1, $_POST['tname'], PDO::PARAM_STR);
      $stmt->execute();
      $row   = $stmt->fetch(PDO::FETCH_ASSOC);
      $dname = $row['iteamname'];
      $query = "insert into teams values (?,?,?,?,?,?)";
      $stmt = $db->prepare($query);
      $stmt->bindParam(1, $_POST['iteamname'], PDO::PARAM_STR);
      $stmt->bindParam(2, $_POST['ilocation'], PDO::PARAM_STR);
      $stmt->bindParam(3, $_POST['iheadcoach'], PDO::PARAM_INT);
      $stmt->bindParam(4, $_POST['iwins'], PDO::PARAM_INT);
      $stmt->bindParam(5, $_POST['ilosses'], PDO::PARAM_INT);
      $stmt->bindParam(6, $_POST['idivision'], PDO::PARAM_INT);
      $stmt->execute();
      header('Location: show_team.php');
    }
  }
?>
