<?php
  include_once("db.php");

      $query = "update players set team_name = ?, number = ?, position = ? where name = ? and team_name = ? and number = ?";
      $stmt = $db->prepare($query);
      $stmt->bindParam(1, $_POST['uteamname'], PDO::PARAM_STR);
      $stmt->bindParam(2, $_POST['unumber'], PDO::PARAM_STR);
      $stmt->bindParam(3, $_POST['uposition'], PDO::PARAM_STR);
      $stmt->bindParam(4, $_POST['uname'], PDO::PARAM_STR);
      $stmt->bindParam(5, $_POST['cteamname'], PDO::PARAM_STR);
      $stmt->bindParam(6, $_POST['cnumber'], PDO::PARAM_STR);
      $stmt->execute();
      header('Location: show_players.php');


?>
