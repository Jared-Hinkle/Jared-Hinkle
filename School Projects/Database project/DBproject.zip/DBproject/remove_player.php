<?php
  include_once("db.php");

      $query = "delete from players where name = ? and team_name = ? and number = ?";
      $stmt = $db->prepare($query);
      $stmt->bindParam(1, $_POST['rname'], PDO::PARAM_STR);
      $stmt->bindParam(2, $_POST['rteamname'], PDO::PARAM_STR);
      $stmt->bindParam(3, $_POST['rnumber'], PDO::PARAM_STR);
      $stmt->execute();
      header('Location: show_players.php');


?>
