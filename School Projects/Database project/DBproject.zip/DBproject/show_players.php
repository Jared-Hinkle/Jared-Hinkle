<!doctype html>
<html>
<style>
body{
    background-color: rgba(200,70,70,.9);
}
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
tr:nth-child(odd){background-color: darkgray}

th {
  background-color: #4CAF50;
  color: white;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
.column-players {
  text-align:center;
  float: left;
  width: 33%;
  padding-bottom: 50px;
  }
  row:after {
  text-align:center;
  content: "";
  display: table;
  clear: both;
  }
  h2,h3,p{
  text-align:center;
  }
</style>
<body>
  <ul>
      <li><a href="main.php">Home</a></li>
      <li><a href="show_team.php">Teams</a></li>
      <li><a class="active" href="show_players.php">Players</a></li>
      <li><a href="show_games.php">Games</a></li>
    </ul>
  <br><br><br>
  <div class="row" >
    <h2>Players Table Interactions </h2>
    <div class="column-players">
      <h3>Add Player</h3>
      <form action="new_player.php" method="post">
        Name: <br><input id="iname" name = 'iname'><br>
        Team Name: <br><input id="iteamname" name = 'iteamname'><br>
        Number: <br><input id="inumber" name = 'inumber'><br>
        Position: <br><input id="iposition" name = 'iposition'><br><br>
        <button id = "add_Player" name = "add_Player">Add Player</button><br>
      </form>
    </div>

    <div class="column-players">
      <h3>Update Player</h3>
      <form action="update_player.php" method="post">
        Name: <br><input id="uname" name = 'uname'><br>
        Current Team Name: <br><input id="cteamname" name = 'cteamname'><br>
        Current Number: <br><input id="cnumber" name = 'cnumber'><br>
        New Team Name: <br><input id="uteamname" name = 'uteamname'><br>
        New Number: <br><input id="unumber" name = 'unumber'><br>
        New Position: <br><input id="uposition" name = 'uposition'><br><br>
        <button id = "update_player" name = "update_player">Update Player</button>
      </form>
    </div>

    <div class="column-players">
      <h3>Remove Player</h3>
      <form action="remove_player.php" method="post">
        Name: <br><input id="rname" name = 'rname'><br>
        Team Name: <br><input id="rteamname" name = 'rteamname'><br>
        Number: <br><input id="rnumber" name = 'rnumber'><br><br>
        <button id = "remove_player" name = "remove_player">Remove Player</button>
      </form>
      <br>
    </div>

  </div>
  <br><br>
  <table>
    <tr>
      <th>Player</th>
      <th>Team</th>
      <th>Number</th>
      <th>Position</th>
    </tr>
</body>
<?php
  include_once("db.php");
  $query = "select * from players";
  $stmt = $db->prepare($query);
  $stmt->execute();
  $count = $stmt->rowCount();
  $results = $stmt->fetchAll();
  if ($count > 0) {
    foreach ($results as $row) {
        $name = $row['name'];
        $teamname = $row['team_name'];
        $number = $row['number'];
        $position = $row['position'];
        echo '<tr><td>'.$name.'</td><td>'.$teamname.'</td><td>'.$number.'</td><td>'.$position.'</td></tr>';
    }
  } else {
    }
    echo'</table>';
?>
</html>
