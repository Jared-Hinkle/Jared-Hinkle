<?php
  include_once("db.php");

      $query = "insert into players (name, team_name, number, position) values (?,?,?,?);";
      $stmt = $db->prepare($query);
      $stmt->bindParam(1, $_POST['iname'], PDO::PARAM_STR);
      $stmt->bindParam(2, $_POST['iteamname'], PDO::PARAM_STR);
      $stmt->bindParam(3, $_POST['inumber'], PDO::PARAM_STR);
      $stmt->bindParam(4, $_POST['iposition'], PDO::PARAM_STR);
      $stmt->execute();
      header('Location: show_players.php');


?>
