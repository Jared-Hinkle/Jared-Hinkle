<!doctype html>
<html>
<style>


body{
    background-color: rgba(200,70,70,.9);
}
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
tr:nth-child(odd){background-color: darkgray}
th {
  background-color: #4CAF50;
  color: white;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
.column-teams {
  text-align:center;
  float: left;
  width: 33%;
  padding-bottom: 50px;
  }
  row:after {
  text-align:center;
  content: "";
  display: table;
  clear: both;
  }
  h2,h3,p{
  text-align:center;
  }
</style>
<body>
  <div class='all'>
  <ul>
      <li><a href="main.php">Home</a></li>
      <li><a class="active" href="show_team.php">Teams</a></li>
      <li><a href="show_players.php">Players</a></li>
      <li><a href="show_games.php">Games</a></li>
    </ul>
  <br><br><br>
  <div class="row" >
    <h2>Teams Table Interactions </h2>
    <div class="column-teams">
      <h3>Add Team</h3>
      <form action="team_select.php" method="post">
        Team Name: <br><input id="iteamname" name = 'iteamname'><br>
        Location: <br><input id="ilocation" name = 'ilocation'><br>
        Head Coach: <br><input id="iheadcoach" name = 'iheadcoach'><br>
        Wins: <br><input id="iwins" name = 'iwins'><br>
        Losses: <br><input id="ilosses" name = 'ilosses'><br>
        Division: <br><input id="idivision" name = 'idivision'><br><br>
        <button id = "add_team" name = "add_team">Add Team</button><br>
      </form>
    </div>

    <div class="column-teams">
      <h3>Update Team Record</h3>
      <form action="update_score.php" method="post">
        Team Name: <br><input id="uteamname" name = 'uteamname'><br>
        Wins: <br><input id="uwins" name = 'uwins'><br>
        Losses: <br><input id="ulosses" name = 'ulosses'><br><br>
        <button id = "update_team" name = "update_team">Update Record</button>
      </form>
    </div>

    <div class="column-teams">
      <h3>Update Team Head Coach</h3>
      <form action="update_coach.php" method="post">
        Team Name: <br><input id="uteamname" name = 'uteamname'><br>
        Head Coach: <br><input id="ucoach" name = 'ucoach'><br><br>
        <button id = "update_team" name = "update_team">Update Record</button>
      </form>
      <br>
    </div>

  </div>
  <br><br>
  <table>
    <tr>
      <th >Team Name</th>
      <th>Location</th>
      <th>Head Coach</th>
      <th>Wins</th>
      <th>Losses</th>
      <th>Divisions</th>
    </tr>
  </div>
</body>
<?php
include_once("db.php");
  $query = "select * from teams";
  $stmt = $db->prepare($query);
  $stmt->execute();
  $count = $stmt->rowCount();
  $results = $stmt->fetchAll();
  if ($count > 0) {
    foreach ($results as $row) {
        $id = $row['location'];
        $teamname = $row['team_name'];
        $headcoach = $row['Head_coach'];
        $location = $row['location'];
        $wins = $row['wins'];
        $losses = $row['losses'];
        $divisions = $row['divisions'];
        echo '<tr><td>'.$teamname.'</td><td>'.$location.'</td><td>'.$headcoach.'</td><td>'.$wins.'</td><td>'.$losses.'</td><td>'.$divisions.'</td></tr>';
    }
  }
  else {
      echo '<option value="0">no department available</option>';
  }
  echo'</table>';
  ?>
</html>
