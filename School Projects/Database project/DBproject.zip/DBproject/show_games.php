<!doctype html>
<html>
<style>
body {
  background-color: rgba(200,70,70,.9);
}
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
tr:nth-child(odd){background-color: darkgray}
th {
  background-color: #4CAF50;
  color: white;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
.column-games {
    text-align:center;
    float: left;
    width: 50%;
    padding-bottom: 50px;
    }
  row:after {
  text-align:center;
  content: "";
  display: table;
  clear: both;
  }
  h2,h3,p{
  text-align:center;
  }
</style>
<body>
  <ul>
      <li><a href="main.php">Home</a></li>
      <li><a href="show_team.php">Teams</a></li>
      <li><a href="show_players.php">Players</a></li>
      <li><a class="active" href="show_games.php">Games</a></li>
    </ul>
  <br><br><br>
  <h2>Games Table Interactions</h2>
  <div class="column-games">
          <h3>Add Game</h3>
          <form action="newgame.php" method="post">
            Date: <br><input id="date" name = 'date'><br>
            Home Team: <br><input id="hometeam" name = 'hometeam'><br>
            Away Team: <br><input id="awayteam" name = 'awayteam'><br>
            Home Team Score: <br><input id="homescore" name = 'homescore'><br>
            Away Team Score: <br><input id="awayscore" name = 'awayscore'><br><br>
            <button id = "newgame" name = "newgame">Add Game</button>
          </form>
        </div>
        <div class="column-games">
          <h3>Update Game</h3>
          <form action="updategame.php" method="post">
            Date: <br><input id="udate" name = 'udate'><br>
            Home Team: <br><input id="uhometeam" name = 'uhometeam'><br>
            Away Team: <br><input id="uawayteam" name = 'uawayteam'><br>
            Home Team Score: <br><input id="uhomescore" name = 'uhomescore'><br>
            Away Team Score: <br><input id="uawayscore" name = 'uawayscore'><br><br>
            <button id = "newgame" name = "newgame">Update Game</button>
          </form>
        </div>
  <br><br>
  <table>
    <tr>
      <th>Date</th>
      <th>Home Team</th>
      <th>Away Team</th>
      <th>Home Team Score</th>
      <th>Away Team Score</th>
      <th>Winner</th>
    </tr>
</body>
<?php
  include_once("db.php");
  $query = "select * from games";
  $stmt = $db->prepare($query);
  $stmt->execute();
  $count = $stmt->rowCount();
  $results = $stmt->fetchAll();
  if ($count > 0) {
    foreach ($results as $row) {
        $date = $row['date'];
        $home_team = $row['home_team'];
        $away_team = $row['away_team'];
        $home_team_score = $row['home_team_score'];
        $away_team_score = $row['away_team_score'];
        echo '<tr><td>'.$date.'</td><td>'.$home_team.'</td><td>'.$away_team.'</td><td>'.$home_team_score.'</td><td>'.$away_team_score.'</td>';
        if($away_team_score > $home_team_score){
          echo '<td>'.$away_team.'</td></tr>';
        }
        else{
          echo '<td>'.$home_team.'</td></tr>';
        }
            }
          }
          else {
              echo '<option value="0">no department available</option>';
          }
          echo'</table>';
?>
</html>
