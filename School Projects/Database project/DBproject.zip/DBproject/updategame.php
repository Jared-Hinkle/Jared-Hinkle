<?php
  include_once("db.php");

      $query = "update games set home_team_score = ?, away_team_score = ? where date = ? and home_team = ? and away_team = ?";
      $stmt = $db->prepare($query);
      $stmt->bindParam(1, $_POST['uhomescore'], PDO::PARAM_STR);
      $stmt->bindParam(2, $_POST['uawayscore'], PDO::PARAM_STR);
      $stmt->bindParam(3, $_POST['udate'], PDO::PARAM_STR);
      $stmt->bindParam(4, $_POST['uhometeam'], PDO::PARAM_STR);
      $stmt->bindParam(5, $_POST['uawayteam'], PDO::PARAM_STR);
      $stmt->execute();
      header('Location: show_games.php');


?>
