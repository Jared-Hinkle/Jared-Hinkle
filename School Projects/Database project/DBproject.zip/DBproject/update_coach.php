<?php
  include_once("db.php");

      $query = "update teams set Head_coach = ? where team_name = ?";
      $stmt = $db->prepare($query);
      $stmt->bindParam(1, $_POST['ucoach'], PDO::PARAM_STR);
      $stmt->bindParam(2, $_POST['uteamname'], PDO::PARAM_STR);
      $stmt->execute();
      header('Location: show_team.php');


?>
