<?php
  include_once("db.php");
  $dname = $row['iteamname'];
  $query = "insert into games values (?,?,?,?,?)";
  $stmt = $db->prepare($query);
  $stmt->bindParam(1, $_POST['date'], PDO::PARAM_STR);
  $stmt->bindParam(2, $_POST['hometeam'], PDO::PARAM_STR);
  $stmt->bindParam(3, $_POST['awayteam'], PDO::PARAM_INT);
  $stmt->bindParam(4, $_POST['homescore'], PDO::PARAM_INT);
  $stmt->bindParam(5, $_POST['awayscore'], PDO::PARAM_INT);
  $stmt->execute();
  header('Location: show_games.php');

?>
